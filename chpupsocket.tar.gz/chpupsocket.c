/*
Creation date (YMD): 2014/01/31
Revision date (YMD):
Programmer: William McEwan; http://arkitektia.com; GPL
Changes:
*/

#include <stdio.h>
int main(int argc, char *argv[])
{
  char *cmdargs[3];

  *cmdargs = "/bin/chown";
  *(cmdargs+1) = *(argv+1);
  *(cmdargs+2) = "/tmp/pup_volume_monitor_socket";
  *(cmdargs+3) = NULL;   
  (void) execv(cmdargs[0], &cmdargs[0]);
}
