Visit the web links for information:
http://murga-linux.com/puppy/viewtopic.php?p=863529#863529
http://murga-linux.com/puppy/viewtopic.php?p=755074#755074

